Authors and contributors, in no particular order:

* Mikhail Korobov <kmike84@gmail.com>
* `Matt Hickford <https://github.com/matt-hickford>`_
* Sergei Lebedev <superbobry@gmail.com>
* Tomasz Melcer <https://github.com/liori>

